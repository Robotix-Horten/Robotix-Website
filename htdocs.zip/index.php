<?php 
	require("header.php");
	require("menu.php");
?>

<div class="container-fluid" id="content">
	<div id="news" class="col-md-7">
		<h1>Nyheter</h1>

		<div class="news-item">
			<h3><span class="timestamp">29. Januar</span> Ny nettside!</h3>
			<p>Nettsiden har trengt en opprydning lenge nå, og det er endelig gjort! Gled dere til mange nye features i fremtiden!</p>
		</div>
	</div>

	<div id="showcase" class="col-md-4">
		<h1>Showcase</h1>
		<img class="img-responsive" src="resources/action.png">
	</div>
</div>


</body>
</html>